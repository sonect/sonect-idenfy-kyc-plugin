//
//  IdenfyKycPlugin.h
//  IdenfyKycPlugin
//
//  Created by Marko Hlebar on 23/03/2020.
//  Copyright © 2020 Sonect. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for IdenfyKycPlugin.
FOUNDATION_EXPORT double IdenfyKycPluginVersionNumber;

//! Project version string for IdenfyKycPlugin.
FOUNDATION_EXPORT const unsigned char IdenfyKycPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IdenfyKycPlugin/PublicHeader.h>


